# 🚀 AI Exam Platform

An AI-powered backend system to generate STEM MCQs from any topic.

## 🔥 Features
- Generate MCQs from topics
- Clean FastAPI backend
- Modular architecture
- Swagger API docs

## 🛠 Tech Stack
- FastAPI
- Python
- Pydantic

## ▶️ Run Project

```bash
pip install fastapi uvicorn
uvicorn app.main:app --reload
```

## 📡 API Endpoint

POST `/api/generate`

### Sample Input
```json
{
  "topic": "Newton Laws",
  "difficulty": "medium",
  "num_questions": 3
}
```

## 📖 Docs
Visit: http://localhost:8000/docs
