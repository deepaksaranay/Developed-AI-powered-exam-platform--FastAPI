from fastapi import FastAPI
from app.api.routes import router

app = FastAPI(title="AI Exam Platform")

app.include_router(router, prefix="/api")

@app.get("/")
def home():
    return {"message": "API is running 🚀"}
