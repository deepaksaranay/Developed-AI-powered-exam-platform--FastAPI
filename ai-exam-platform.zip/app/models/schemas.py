from pydantic import BaseModel
from typing import List

class Option(BaseModel):
    key: str
    text: str

class Question(BaseModel):
    question: str
    options: List[Option]
    correct_answer: str
    explanation: str

class MCQRequest(BaseModel):
    topic: str
    difficulty: str = "medium"
    num_questions: int = 5
