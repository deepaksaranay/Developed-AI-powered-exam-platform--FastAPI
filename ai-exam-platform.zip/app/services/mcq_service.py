import random

def generate_mcqs(topic: str, num_questions: int):
    questions = []

    for i in range(num_questions):
        q = {
            "question": f"Sample question {i+1} on {topic}?",
            "options": [
                {"key": "A", "text": "Option A"},
                {"key": "B", "text": "Option B"},
                {"key": "C", "text": "Option C"},
                {"key": "D", "text": "Option D"},
            ],
            "correct_answer": random.choice(["A", "B", "C", "D"]),
            "explanation": "This is a sample explanation"
        }
        questions.append(q)

    return questions
