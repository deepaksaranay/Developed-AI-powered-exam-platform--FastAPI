from fastapi import APIRouter
from app.models.schemas import MCQRequest
from app.services.mcq_service import generate_mcqs

router = APIRouter()

@router.post("/generate")
def generate(request: MCQRequest):
    data = generate_mcqs(request.topic, request.num_questions)
    return {
        "topic": request.topic,
        "questions": data
    }
