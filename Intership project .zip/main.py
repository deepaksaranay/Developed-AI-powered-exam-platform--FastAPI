from agents.youtube_agent import fetch_youtube_data
from agents.sentiment_agent import analyze_sentiment
from agents.nse_agent import get_bulk_block_deals

def main():
    yt_data = fetch_youtube_data()
    sentiment = analyze_sentiment(yt_data)
    deals = get_bulk_block_deals()

    print("Sentiment:", sentiment)
    print("Deals:", deals)

if __name__ == "__main__":
    main()
