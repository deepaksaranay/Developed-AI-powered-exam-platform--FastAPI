# CrowdWisdomTrading AI Agent

## Overview
Backend Python project using Hermes Agents for sentiment analysis on NSE stocks using YouTube data.

## Features
- Fetch Bulk & Block Deals
- Scrape YouTube videos via Apify
- Sentiment Analysis using LLM (OpenRouter)
- Chatbot with RAG
- Source citation
- Closed learning loop

## Run
```bash
pip install -r requirements.txt
python main.py
```
