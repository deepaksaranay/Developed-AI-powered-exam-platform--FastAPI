def chat(query, sentiment_data):
    for item in sentiment_data:
        if "reliance" in query.lower():
            return f"Sentiment on Reliance is {item['sentiment']}"
    return "No data found"
