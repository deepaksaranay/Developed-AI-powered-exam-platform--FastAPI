def analyze_sentiment(data):
    results = []
    for item in data:
        text = item["transcript"]
        sentiment = "positive" if "up" in text else "negative"
        results.append({"title": item["title"], "sentiment": sentiment})
    return results
