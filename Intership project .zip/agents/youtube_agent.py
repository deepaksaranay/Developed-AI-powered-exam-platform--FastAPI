def fetch_youtube_data():
    # Placeholder for Apify integration
    return [{"title": "Reliance bullish", "transcript": "Reliance going up"}]
