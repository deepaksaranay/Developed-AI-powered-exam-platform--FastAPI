def get_bulk_block_deals():
    # Placeholder for NSE data
    return [{"stock": "RELIANCE", "activity": "High buying"}]
